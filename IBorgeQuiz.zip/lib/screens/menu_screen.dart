import 'package:flutter/material.dart';
import 'package:quizforfun/constants.dart';
import 'package:quizforfun/screens/game_screen.dart';

class MenuScreen extends StatelessWidget {
  static const String id = 'menu';

  const MenuScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
          const Text('Bienvenidos \n a Quiz For \n Fun !!',
          style: k_bigTitleTextStyle, textAlign: TextAlign.center),
      Container(
        padding: EdgeInsets.all(8.0),
          height: 50,
          width: 150,
          decoration: BoxDecoration(
            color: Colors.grey,
            borderRadius: BorderRadius.all(Radius.circular(20))
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () => Navigator.pushNamed(context, GameScreen.id),
                child: const Text('Empezar', style: k_buttonTextStyle),
              ),
            ],
          )
      ),
     ])
    );
  }
}
