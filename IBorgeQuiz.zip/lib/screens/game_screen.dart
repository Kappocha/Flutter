import 'package:flutter/material.dart';
import 'package:quizforfun/constants.dart';
import 'package:quizforfun/screens/end_screen.dart';


class GameScreen extends StatefulWidget {
  static const String id = 'game';

  const GameScreen({Key? key}) : super(key: key);

  @override
  State<GameScreen> createState() => _GameScreenState();
}



class _GameScreenState extends State<GameScreen> {

  int PregTotal = 0;
  int PregAct = 0;
  int RespAct = 4;
  int RespuestaBuena = 4;
  int RespJug = 0;

  int aciertos = 0;
  int fallos = 0;

  List<String> resp1 = ["1", "5", "999", "1000"];
  List<String> resp2 = [
    "Blanco y Negro",
    "Verde y Blanco",
    "Rojo y Amarillo",
    "Azul y Rojo"
  ];
  String preg1 =
      "Don Juan de Troya \n con una  lanza de \n mil metros. \n Cuantos metros \n mide la lanza de Juan?";
  String preg2 = "De que color es la bandera \n de espana?";


  void Revisar(int NPuls){
    setState(() {
      print(NPuls);
      if(NPuls == RespuestaBuena){
        print("Buena");
        PregTotal += 1;
        aciertos+=1;
      } else {
        print("Mala");
        fallos+=1;
        PregTotal += 1;
      }
      if (PregAct == 0){
        PregAct = 1;
        RespuestaBuena = 3;
      } else if (PregAct == 1) {
        PregAct = 0;
        RespuestaBuena = 4;
      }
      if (PregTotal >= 2){
        Navigator.pushNamed(context, EndScreen.id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    List<String> preguntas = [preg1, preg2];
    List<List> respuestas = [resp1, resp2];

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black87,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              color: Colors.black54,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check),
                  Text('${aciertos}',
                            style: k_buttonTextStyle),
                  Icon(Icons.close),
                  Text('${fallos}', style: k_buttonTextStyle),
                ],
              ),
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    preguntas[PregAct],
                    style: TextStyle(fontSize: 32),
                  )
                ],
              ),
            ),
            Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          width: 300,
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(onPressed: () => Revisar(1),
                                  child: Text(respuestas[PregAct][0], style: TextStyle(color: Colors.white)))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          width: 300,
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(onPressed: () => Revisar(2),
                                  child: Text(respuestas[PregAct][1], style: TextStyle(color: Colors.white)))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          width: 300,
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(onPressed: () => Revisar(3),
                                  child: Text(respuestas[PregAct][2], style: TextStyle(color: Colors.white)))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          width: 300,
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(onPressed: () => Revisar(4),
                                  child: Text(respuestas[PregAct][3], style: TextStyle(color: Colors.white),))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
