import 'package:flutter/material.dart';
import 'package:quizforfun/constants.dart';
import 'package:quizforfun/screens/game_screen.dart';

class EndScreen extends StatelessWidget {
  static const String id = 'end';

  const EndScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('FIN', textAlign: TextAlign.center, textScaleFactor: 3),
          const SizedBox(height: 25),
        ],
      ),
    );
  }
}