import 'package:flutter/cupertino.dart';

class GameLogic{
ValueNotifier<int> Fallos = ValueNotifier(0);
ValueNotifier<int> Aciertos = ValueNotifier(0);

}