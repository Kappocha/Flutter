import 'package:flutter/material.dart';

const k_gameCellButtonStyle = ButtonStyle(
  backgroundColor: MaterialStatePropertyAll<Color>(Colors.grey),
);

const k_titleTextStyle = TextStyle(
  fontFamily: 'Roboto',
  fontSize: 52,
);

const k_bigTitleTextStyle = TextStyle(
  fontFamily: 'Roboto',
  fontSize: 74,
  fontStyle: FontStyle.italic,
);

const k_buttonTextStyle = TextStyle(
  fontFamily: 'Roboto',
  fontSize: 24,
  color: Colors.white,
);