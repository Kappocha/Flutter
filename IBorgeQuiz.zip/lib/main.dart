import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quizforfun/screens/end_screen.dart';
import 'package:quizforfun/screens/game_screen.dart';
import 'package:quizforfun/screens/menu_screen.dart';

void main() {
  runApp(const QuizForFun());
}

class QuizForFun extends StatelessWidget {
  const QuizForFun({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
      initialRoute: MenuScreen.id,
      routes: {
        MenuScreen.id: (context) => const MenuScreen(),
        GameScreen.id: (context) => const GameScreen(),
        EndScreen.id: (context) => const EndScreen(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
